This folder will contain the exercise files and details for Udacity Module - Cloud Data Warehouse
