Data Lakes with Spark Exercise Files
