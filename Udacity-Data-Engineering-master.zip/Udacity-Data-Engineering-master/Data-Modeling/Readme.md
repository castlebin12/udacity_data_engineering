Data Modeling with Postgres and Apache Cassandra

Exercise and Projects
